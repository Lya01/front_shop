class Prodotto {
  int id;
  String nome;
  String descrizione;
  String image;
  double prezzo;
  int disponibilita;


  Prodotto({required this.id,required this.nome,required this.descrizione, required this.image,required this.prezzo,required this.disponibilita});

  factory Prodotto.fromJson(Map<String, dynamic> json) {
    return Prodotto(
      id: json['id'],
      nome: json['nome'],
      descrizione: json['descrizione'],
      image: json['image'],
      prezzo: json['prezzo'],
      disponibilita: json['disponibilita']
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'nome': nome,
    'descrizione': descrizione,
    'image': image,
    'prezzo':prezzo,
    'disponibilita':disponibilita
  };

}