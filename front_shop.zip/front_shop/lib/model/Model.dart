import 'dart:async';
import 'dart:convert';

import 'package:front_shop/model/managers/RestManager.dart';
import 'package:front_shop/model/objects/Customer.dart';
import 'package:front_shop/model/objects/Prodotto.dart';
import 'package:front_shop/model/support/Constants.dart';



class Model {
  static Model sharedInstance = Model();

  RestManager _restManager = RestManager();







  Future<List<Prodotto>?> searchProduct(String name) async {
    Map<String, String> params = Map();
    params["name"] = name;
    try {
      return List<Prodotto>.from(json.decode(await _restManager.makeGetRequest(Constants.ADDRESS_STORE_SERVER, Constants.REQUEST_SEARCH_PRODUCTS, params)).map((i) => Prodotto.fromJson(i)).toList());
    }
    catch (e) {
      return null; // not the best solution
    }
  }

  Future<Customer?> addUser(Customer user) async {
    try {
      String rawResult = await _restManager.makePostRequest(Constants.ADDRESS_STORE_SERVER, Constants.REQUEST_ADD_USER, user);
      if ( rawResult.contains(Constants.RESPONSE_ERROR_MAIL_USER_ALREADY_EXISTS) ) {
        return null; // not the best solution
      }
      else {
        return Customer.fromJson(jsonDecode(rawResult));
      }
    }
    catch (e) {
      return null; // not the best solution
    }
  }


}
