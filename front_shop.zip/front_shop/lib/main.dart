import 'package:flutter/material.dart';
import 'package:front_shop/UI/App.dart';

void main() => runApp(App());